from django.urls import path
from rag_app import views

app_name = "rag_app"

urlpatterns = [
    # Main chat interface page (rendered by a class-based view)
    path("", views.ChatView.as_view(), name="chat"),

    # API endpoints (functional views)
    path("api/ask/", views.ask_question_api, name="ask_question_api"),
    path("api/search/", views.search_documents_api, name="search_documents_api"),
    path("api/health/", views.health_check_api, name="health_check_api"),
    path("api/history/", views.chat_history_api, name="chat_history_api"),

    # Analytics page (rendered by a class-based view)
    path("analytics/", views.AnalyticsView.as_view(), name="analytics"),
]

