# src/rag_app/rag_engine.py - Optimized for Speed

import os
import pickle
import faiss
import logging
import torch
from typing import List, Tuple, Dict
from sentence_transformers import SentenceTransformer
from llama_cpp import Llama
from django.conf import settings
import threading
import time
import sys

# Fix Unicode logging issues


logger = logging.getLogger(__name__)

class MauritaniaRAG:
    def __init__(self):
        self.config = settings.RAG_CONFIG
        self.embedding_model = None
        self.llm = None
        self.index = None
        self.metadatas = []
        self.documents = []  # Add this for compatibility
        self.initialized = False
        self.device = "cuda" if torch.cuda.is_available() else "cpu"
        self._lock = threading.Lock()
        # Pre-compiled context template for speed
        self.context_template = """أجب  إجابة تفصيلية على السؤال بناءً على السياق التالي:

{context}

السؤال: {question}
الإجابة التفصيلية:"""
        
        logger.info(f"Using device for embeddings: {self.device}")
        self.initialize()

    def initialize(self):
        """Initialize all models and load data with optimizations."""
        if self.initialized:
            return

        with self._lock:
            if self.initialized:
                return

            try:
                # Load embedding model with optimizations
                self._load_embedding_model()
                
                # Load GGUF model with speed optimizations
                self._load_gguf_model()
                
                # Load FAISS index
                self._load_vector_store()
                
                self.initialized = True
                logger.info("RAG engine initialized successfully!")

            except Exception as e:
                logger.error(f"Failed to initialize RAG engine: {e}")
                raise

    def _load_embedding_model(self):
        """Load embedding model with speed optimizations."""
        emb_model_name = self.config['EMBEDDING_MODEL_NAME']
        logger.info(f"Loading embedding model: {emb_model_name}...")
        
        # Use smaller, faster model for speed
        if "MiniLM" in emb_model_name:
            # Already using MiniLM which is good for speed
            self.embedding_model = SentenceTransformer(emb_model_name, device=self.device)
        else:
            # Fallback to faster model
            self.embedding_model = SentenceTransformer(
                'sentence-transformers/all-MiniLM-L6-v2', 
                device=self.device
            )
        
        # Set to eval mode and optimize
        self.embedding_model.eval()
        if hasattr(self.embedding_model, '_modules'):
            for module in self.embedding_model._modules.values():
                if hasattr(module, 'eval'):
                    module.eval()

    def _load_gguf_model(self):
        """Load GGUF model with maximum speed optimizations."""
        model_path = self.config.get('GGUF_MODEL_PATH', 'models/SILMA-Kashif-2B-Instruct-v1.0.i1-IQ3_XS.gguf')
        
        if not os.path.exists(model_path):
            raise FileNotFoundError(f"GGUF model not found at {model_path}")

        logger.info(f"Loading GGUF model with speed optimizations...")
        
        # Optimized parameters for maximum speed
        n_gpu_layers = -1 if torch.cuda.is_available() else 0
        n_ctx = min(self.config.get('CONTEXT_LENGTH', 1024), 1024)  # Smaller context for speed
        n_threads = os.cpu_count() or 4  # Use all CPU cores
        
        try:
            self.llm = Llama(
                model_path=str(model_path),  # Ensure string path
                n_gpu_layers=n_gpu_layers,
                n_ctx=n_ctx,
                n_threads=n_threads,
                n_batch=512,  # Batch size for processing
                verbose=False,
                use_mmap=True,  # Memory mapping for faster loading
                use_mlock=False,  # Don't lock memory
                seed=-1,  # Random seed
                f16_kv=True,  # Use 16-bit for key-value cache
                logits_all=False,  # Don't compute all logits
                vocab_only=False,
                embedding=False,
                chat_format="chatml"
            )
            
            logger.info(f"GGUF model loaded with {n_gpu_layers} GPU layers, {n_threads} threads")
            
        except Exception as e:
            logger.error(f"Failed to load GGUF model: {e}")
            # Retry with minimal settings
            self.llm = Llama(
                model_path=str(model_path),
                n_gpu_layers=0,
                n_ctx=512,  # Very small context
                n_threads=2,
                verbose=False,
                use_mmap=True,
                chat_format="chatml"
            )
            logger.info("GGUF model loaded with minimal settings")

    def _load_vector_store(self):
        """Load FAISS index and metadata with optimizations."""
        index_path = self.config["VECTOR_INDEX_PATH"]
        metadata_path = self.config["METADATA_PATH"]

        if not os.path.exists(index_path) or not os.path.exists(metadata_path):
            raise FileNotFoundError("FAISS index or metadata not found. Run indexing script first.")

        # Load with memory mapping for speed
        self.index = faiss.read_index(str(index_path))
        
        # Optimize FAISS index for speed
        if hasattr(self.index, 'nprobe'):
            self.index.nprobe = min(32, self.index.nprobe or 32)  # Limit search probes
        
        with open(metadata_path, "rb") as f:
            self.metadatas = pickle.load(f)
            
        # Create documents list for compatibility
        self.documents = [meta.get('text', '') for meta in self.metadatas]

        logger.info(f"Loaded {self.index.ntotal} vectors and {len(self.metadatas)} metadata entries")

    def search_documents(self, query: str, top_k: int = None) -> List[Dict]:
        """Optimized document search."""
        if not self.initialized:
            self.initialize()

        if top_k is None:
            top_k = min(self.config.get("TOP_K_RESULTS", 5), 3)  # Limit for speed

        # Truncate query for speed
        query = query[:200] if len(query) > 200 else query
        
        try:
            # Fast encoding with no gradients
            with torch.no_grad():
                query_vector = self.embedding_model.encode([query], convert_to_tensor=False)
            
            # Quick FAISS search
            distances, indices = self.index.search(query_vector, top_k)
            
            results = []
            for i, (idx, score) in enumerate(zip(indices[0], distances[0])):
                if 0 <= idx < len(self.metadatas):
                    metadata_entry = self.metadatas[idx]
                    if isinstance(metadata_entry, dict) and 'text' in metadata_entry:
                        # Truncate content for speed
                        content = metadata_entry.get('text', '').strip()[:500]
                        results.append({
                            "rank": i + 1,
                            "content": content,
                            "source": metadata_entry.get("source", "Unknown"),
                            "similarity_score": float(score),
                            "chunk_id": int(idx)
                        })

            return results
            
        except Exception as e:
            logger.error(f"Search error: {e}")
            return []

    def generate_answer(self, question: str, context_chunks: List[str]) -> Dict:
        """Ultra-fast answer generation."""
        if not self.initialized or not self.llm:
            return {"answer": "عذراً، الخدمة غير متاحة حالياً.", "confidence": 0.0}

        if not context_chunks:
            return {"answer": "لم أجد معلومات ذات صلة.", "confidence": 0.0}

        # Limit context size for speed
        limited_context = []
        total_chars = 0
        max_context = 800  # Very limited context for speed
        
        for chunk in context_chunks:
            if total_chars + len(chunk) > max_context:
                break
            limited_context.append(chunk[:300])  # Truncate each chunk
            total_chars += len(chunk[:300])

        context_str = "\n".join(limited_context)
        
        # Truncate question for speed
        question = question[:150] if len(question) > 150 else question
        
        prompt = self.context_template.format(
            context=context_str,
            question=question
        )

        try:
            start_time = time.time()
            
            # Ultra-fast generation settings
            response = self.llm(
                prompt,
                max_tokens=80,  # Very short responses
                temperature=0.1,  # Lower temperature for speed
                top_p=0.7,
                top_k=20,  # Smaller search space
                repeat_penalty=1.05,
                stop=["السؤال:", "\n\n", "السياق:", "---"],
                echo=False,
                stream=False  # No streaming for simplicity
            )
            
            generation_time = time.time() - start_time
            
            if response and 'choices' in response and response['choices']:
                answer = response['choices'][0]['text'].strip()
                
                # Quick cleanup
                if answer.startswith("الإجابة"):
                    answer = answer.split(":", 1)[-1].strip()
                
                # Remove empty lines
                answer = " ".join(line.strip() for line in answer.split('\n') if line.strip())
                
                if not answer:
                    answer = "لم أتمكن من إنتاج إجابة واضحة."
                    
            else:
                answer = "حدث خطأ في الإجابة."
                
            # Simple confidence based on length and generation time
            confidence = min(0.9, len(answer) / 100.0) if answer else 0.1
            
            return {
                "answer": answer,
                "confidence": confidence,
                "generation_time": generation_time,
                "model_type": "gguf_fast"
            }
            
        except Exception as e:
            logger.error(f"Generation error: {e}")
            return {"answer": "عذراً، حدث خطأ في الإجابة.", "confidence": 0.0}

    def ask_question(self, question: str) -> Dict:
        """Optimized main RAG pipeline."""
        if not self.initialized:
            self.initialize()

        # Avoid logging Arabic text that causes encoding issues
        logger.info("Processing user question...")
        start_time = time.time()
        
        # Fast document search with fewer results
        relevant_docs = self.search_documents(question, top_k=3)
        search_time = time.time() - start_time

        if not relevant_docs:
            return {
                "answer": "لم أجد معلومات ذات صلة.",
                "confidence": 0.0,
                "sources": [],
                "retrieved_documents": [],
                "search_time": search_time,
                "generation_time": 0,
                "total_time": search_time
            }

        # Use only top 2 documents for context
        context_docs = relevant_docs[:2]
        context_chunks = [doc["content"] for doc in context_docs]

        # Fast generation
        generation_start = time.time()
        generation_result = self.generate_answer(question, context_chunks)
        generation_time = time.time() - generation_start

        # Minimal source preparation
        sources = [
            {
                "source": doc["source"],
                "rank": doc["rank"],
                "similarity": round(doc["similarity_score"], 3)
            }
            for doc in relevant_docs[:3]  # Limit sources
        ]

        total_time = time.time() - start_time

        response = {
            "answer": generation_result["answer"],
            "confidence": generation_result.get("confidence"),
            "sources": sources,
            "retrieved_documents": relevant_docs,
            "context_used": " ".join(context_chunks)[:300] + "..." if len(" ".join(context_chunks)) > 300 else " ".join(context_chunks),
            "search_time": round(search_time, 2),
            "generation_time": round(generation_result.get("generation_time", generation_time), 2),
            "total_time": round(total_time, 2),
            "model_type": "fast_rag"
        }

        logger.info(f"Response generated in {total_time:.2f}s (search: {search_time:.2f}s, gen: {generation_time:.2f}s)")
        return response

# Singleton instance
rag_engine = MauritaniaRAG()