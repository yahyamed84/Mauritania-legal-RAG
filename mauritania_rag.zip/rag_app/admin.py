from django.contrib import admin
from .models import ChatMessage, DocumentSource, SearchQuery

# Register your models here to make them accessible in the Django admin interface.

@admin.register(ChatMessage)
class ChatMessageAdmin(admin.ModelAdmin):
    list_display = (
        "question",
        "answer",
        "confidence",
        "created_at",
        "session_id",
    )
    list_filter = ("created_at", "confidence")
    search_fields = ("question", "answer")
    readonly_fields = ("created_at",)

@admin.register(DocumentSource)
class DocumentSourceAdmin(admin.ModelAdmin):
    list_display = (
        "filename",
        "processed_at",
        "chunk_count",
        "file_size",
        "is_active",
    )
    list_filter = ("is_active", "processed_at")
    search_fields = ("filename", "file_path")
    readonly_fields = ("processed_at",)

@admin.register(SearchQuery)
class SearchQueryAdmin(admin.ModelAdmin):
    list_display = (
        "query",
        "results_count",
        "response_time",
        "created_at",
        "user_ip",
    )
    list_filter = ("created_at",)
    search_fields = ("query",)
    readonly_fields = ("created_at",)

