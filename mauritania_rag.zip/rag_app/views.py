import json
import logging
from django.shortcuts import render
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_http_methods
from django.views import View
from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework import status
from .rag_engine import rag_engine
from .models import ChatMessage, SearchQuery
from django.db.models import Avg
import time

logger = logging.getLogger(__name__)

class ChatView(View):
    """Renders the main chat interface page."""
    def get(self, request):
        return render(request, 'chat.html')

@csrf_exempt
@require_http_methods(["POST"])
def ask_question_api(request):
    """Optimized API endpoint for fast question answering."""
    try:
        data = json.loads(request.body)
        question = data.get('question', '').strip()
        session_id = data.get('session_id')

        if not question:
            return JsonResponse({
                'error': 'السؤال مطلوب.',
                'success': False
            }, status=400)

        # Log without Arabic text to avoid encoding issues
        logger.info("Processing user question")

        # Get answer from RAG engine
        start_time = time.time()
        result = rag_engine.ask_question(question)
        response_time = time.time() - start_time

        # Save to database (optional, skip for maximum speed)
        if not data.get('skip_save', False):
            try:
                ChatMessage.objects.create(
                    question=question,
                    answer=result['answer'],
                    confidence=result['confidence'],
                    sources=result['sources'],
                    session_id=session_id
                )
            except Exception as e:
                logger.warning(f"Failed to save chat message: {e}")

        return JsonResponse({
            'success': True,
            'answer': result['answer'],
            'confidence': result['confidence'],
            'sources': result['sources'],
            'context': result.get('context_used', ''),
            'retrieved_docs_count': len(result.get('retrieved_documents', [])),
            'response_time': round(response_time, 2),
            'search_time': result.get('search_time', 0),
            'generation_time': result.get('generation_time', 0)
        })

    except json.JSONDecodeError:
        return JsonResponse({
            'error': 'بيانات JSON غير صحيحة.',
            'success': False
        }, status=400)
    except Exception as e:
        logger.error(f"Error processing question: {e}")
        return JsonResponse({
            'error': 'حدث خطأ غير متوقع. يرجى المحاولة مرة أخرى.',
            'success': False
        }, status=500)

@api_view(['GET'])
def search_documents_api(request):
    """Fast document search API."""
    try:
        query = request.GET.get('q', '').strip()
        try:
            top_k = min(int(request.GET.get('top_k', 3)), 5)  # Cap at 5 for speed
        except ValueError:
            return Response({
                'error': 'معامل top_k يجب أن يكون رقماً صحيحاً.',
                'success': False
            }, status=status.HTTP_400_BAD_REQUEST)

        if not query:
            return Response({
                'error': 'معامل البحث \'q\' مطلوب.',
                'success': False
            }, status=status.HTTP_400_BAD_REQUEST)

        logger.info("Performing document search")
        start_time = time.time()
        results = rag_engine.search_documents(query, top_k)
        response_time = time.time() - start_time

        # Skip logging to database for speed
        if not request.GET.get('skip_log', False):
            try:
                SearchQuery.objects.create(
                    query=query,
                    results_count=len(results),
                    response_time=response_time,
                    user_ip=request.META.get('REMOTE_ADDR')
                )
            except Exception as e:
                logger.warning(f"Failed to save search query: {e}")

        return Response({
            'success': True,
            'query': query,
            'results': results,
            'total_found': len(results),
            'response_time': round(response_time, 2)
        })

    except Exception as e:
        logger.error(f"Error during document search: {e}")
        return Response({
            'error': 'حدث خطأ أثناء البحث في المستندات.',
            'success': False
        }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

@api_view(['GET'])
def health_check_api(request):
    """Fast health check endpoint."""
    try:
        rag_status = {
            'initialized': rag_engine.initialized,
            'documents_loaded': len(rag_engine.documents) if rag_engine.initialized else 0,
            'index_loaded': rag_engine.index.ntotal if rag_engine.initialized and rag_engine.index else 0
        }

        # Quick DB check
        db_ok = True
        try:
            ChatMessage.objects.count()
        except Exception:
            db_ok = False

        status_code = status.HTTP_200_OK if rag_status['initialized'] and db_ok else status.HTTP_503_SERVICE_UNAVAILABLE

        return Response({
            'status': 'healthy' if rag_status['initialized'] and db_ok else 'unhealthy',
            'rag_status': rag_status,
            'database_status': 'connected' if db_ok else 'error'
        }, status=status_code)

    except Exception as e:
        logger.error(f"Health check failed: {e}")
        return Response({
            'status': 'unhealthy',
            'error': str(e)
        }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

@api_view(['GET'])
def chat_history_api(request):
    """Fast chat history retrieval."""
    try:
        count = min(int(request.GET.get('count', 10)), 50)  # Limit for speed
        session_id = request.GET.get('session_id')

        query = ChatMessage.objects.order_by('-created_at')
        if session_id:
            query = query.filter(session_id=session_id)

        recent_chats = query[:count]

        history = []
        for chat in recent_chats:
            history.append({
                'id': chat.id,
                'question': chat.question[:100] + '...' if len(chat.question) > 100 else chat.question,  # Truncate for speed
                'answer': chat.answer[:200] + '...' if len(chat.answer) > 200 else chat.answer,  # Truncate for speed
                'confidence': chat.confidence,
                'sources': chat.sources[:3] if isinstance(chat.sources, list) and len(chat.sources) > 3 else chat.sources,  # Limit sources
                'created_at': chat.created_at.isoformat(),
                'session_id': chat.session_id
            })

        return Response({
            'success': True,
            'history': history
        })

    except ValueError:
        return Response({
            'error': 'معامل count يجب أن يكون رقماً صحيحاً.',
            'success': False
        }, status=status.HTTP_400_BAD_REQUEST)
    except Exception as e:
        logger.error(f"Error retrieving chat history: {e}")
        return Response({
            'error': 'حدث خطأ أثناء استرجاع سجل المحادثات.',
            'success': False
        }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

class AnalyticsView(View):
    """Renders an analytics dashboard page."""
    def get(self, request):
        try:
            total_questions = ChatMessage.objects.count()
            # Calculate average confidence, handle case where there are no messages
            avg_confidence_result = ChatMessage.objects.aggregate(avg_conf=Avg('confidence'))
            avg_confidence = avg_confidence_result['avg_conf'] if avg_confidence_result['avg_conf'] is not None else 0

            # Get RAG engine status safely
            documents_count = len(rag_engine.documents) if rag_engine.initialized else "غير متاح" # 'Not Available'

            context = {
                'total_questions': total_questions,
                'avg_confidence': round(avg_confidence, 3),
                'documents_count': documents_count,
                # Add more stats if needed (e.g., unique users, popular sources)
            }

            # Render an analytics template (you'll need to create analytics.html)
            return render(request, 'analytics.html', context)
        except Exception as e:
            logger.error(f"Error rendering analytics view: {e}", exc_info=True)
            # Render the template with an error message
            return render(request, 'analytics.html', {'error': 'حدث خطأ أثناء تحميل بيانات الإحصائيات.'}) # 'Error loading analytics data.'

